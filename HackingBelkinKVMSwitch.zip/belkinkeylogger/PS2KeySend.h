/*
 * PS2KeySend - send key press data on PS/2 bus
 *
 * Copyright (C) 2017 Ian Payton, Cisco
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

class PS2KeySend {
    public:
        static PS2KeySend *getInstance();
        
        void begin(uint8_t OutClockPin, uint8_t OutDataPin);
        void send(uint8_t ch);
        void query();
        void waitForIdle();
        void end();

        static void KeyISR();

    private:
        PS2KeySend();

        typedef enum {
            IDLE, PENDING, START, DATA, PARITY, STOP, WAIT
        } State;

        static uint8_t  _OutClockPin;
        static uint8_t  _OutDataPin;
        
        static uint8_t  _keyb_i;
        static uint8_t  _keyb_len;
        static uint8_t  _keyb_bit;
        static uint8_t  _keyb_parity;
        static uint8_t  _keyb_clock;
        static const uint8_t *_keyb_data;
        static volatile State    _keyb_state;
};

