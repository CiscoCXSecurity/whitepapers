/*
 * PS2KeySend - send key press data on PS/2 bus
 *
 * Copyright (C) 2017 Ian Payton, Cisco
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

#include <Arduino.h>

#include "PS2KeySend.h"

#undef DEBUG
#define DEBUG

#define WAITCLOCKS 100

uint8_t  PS2KeySend::_OutClockPin;
uint8_t  PS2KeySend::_OutDataPin;

uint8_t  PS2KeySend::_keyb_i;
uint8_t  PS2KeySend::_keyb_len;
uint8_t  PS2KeySend::_keyb_bit;
uint8_t  PS2KeySend::_keyb_parity;
uint8_t  PS2KeySend::_keyb_clock;
volatile PS2KeySend::State PS2KeySend::_keyb_state;

const uint8_t *PS2KeySend::_keyb_data;
static uint8_t keypress_buf[3] = { 0x00, 0xF0, 0x00 };

static uint8_t waitclocks = 100;

static const uint8_t alphaScanCodes[] = {
    /* a */ 0x1C,
    /* b */ 0x32,
    /* c */ 0x21,
    /* d */ 0x23,
    /* e */ 0x24,
    /* f */ 0x2B,
    /* g */ 0x34,
    /* h */ 0x33,
    /* i */ 0x43,
    /* j */ 0x3B,
    /* k */ 0x42,
    /* l */ 0x4B,
    /* m */ 0x3A,
    /* n */ 0x31,
    /* o */ 0x44,
    /* p */ 0x4D,
    /* q */ 0x15,
    /* r */ 0x2D,
    /* s */ 0x1B,
    /* t */ 0x2C,
    /* u */ 0x3C,
    /* v */ 0x2A,
    /* w */ 0x1D,
    /* x */ 0x22,
    /* y */ 0x35,
    /* z */ 0x1A
};

static const uint8_t numberScanCodes[] = {
    /* 0 */ 0x45,
    /* 1 */ 0x16,
    /* 2 */ 0x1E,
    /* 3 */ 0x26,
    /* 4 */ 0x25,
    /* 5 */ 0x2E,
    /* 6 */ 0x36,
    /* 7 */ 0x3D,
    /* 8 */ 0x3E,
    /* 9 */ 0x46
};

PS2KeySend *PS2KeySend::getInstance()
{
    static PS2KeySend instance;
    
    return &instance;
}

PS2KeySend::PS2KeySend()
{
    _keyb_i = 0xFF;
    _keyb_len = 0;
    _keyb_bit = 0;
    _keyb_parity = 1;
    _keyb_clock = 1;
    _keyb_data = keypress_buf;
    _keyb_state = IDLE;
}

void PS2KeySend::begin(uint8_t OutClockPin, uint8_t OutDataPin)
{
    _OutClockPin = OutClockPin;
    _OutDataPin = OutDataPin;
    
    // Set up I/O for keyboard output
    pinMode(_OutClockPin, INPUT);
    pinMode(_OutDataPin, INPUT);

    // Set up 25kHz timer interrupt
    cli();//stop interrupts

    // Use Timer 1, as Timer 0 is used by the system
    //set timer1 interrupt at 1Hz
    TCCR1A = 0;// set entire TCCR1A register to 0
    TCCR1B = 0;// same for TCCR1B
    TCNT1  = 0;//initialize counter value to 0
    // set compare match register for 12.5kHz increments
    OCR1A = 9;// = (16*10^6) / (25000*64) - 1 (must be <65536)
    // turn on CTC mode
    TCCR1B |= (1 << WGM12);
    // Set CS11 and CS10 bits for 64 prescaler
    TCCR1B |= (1 << CS11) | (1 << CS10);  
    // enable timer compare interrupt
    TIMSK1 |= (1 << OCIE1A);    
    
    sei();
}

void PS2KeySend::end()
{
    // Just disable interrupts for timer 2
    TIMSK1 &= ~(1 << OCIE1A);    
}

void PS2KeySend::waitForIdle()
{
    while (_keyb_state != IDLE);
}

void PS2KeySend::send(uint8_t ch)
{
    // Wait for IDLE state, and then put us 'PENDING'
    while (_keyb_state != IDLE);
    _keyb_state = PENDING;
    
    uint8_t code = 0x49; // dot
    if (ch >= '0' && ch <= '9') {
        code = numberScanCodes[ch - '0'];
    }
    if (ch >= 'a' && ch <= 'z') {
        code = alphaScanCodes[ch - 'a'];
    }
    if (ch >= 'A' && ch <= 'Z') {
        code = alphaScanCodes[ch - 'A'];
    }
    if (ch == '\n') {
        code = 0x5A;
    }
    
    keypress_buf[0] = code;
    keypress_buf[1] = 0xF0;
    keypress_buf[2] = code;
    _keyb_len = 3;
    
#ifdef DEBUG
    Serial.print("Sending scan code ");
    Serial.println(code, DEC);
#endif
    // Trigger the output of a key
    _keyb_i = 0;
}

void PS2KeySend::query()
{
    Serial.print("keyb_i = ");
    Serial.println(_keyb_i, DEC);
}

ISR(TIMER1_COMPA_vect)
{
    PS2KeySend::KeyISR();
}

void PS2KeySend::KeyISR()
{
    // Send key.  Only do it if keyb_i < keyb_len
    if (_keyb_i < _keyb_len) {
        switch (_keyb_state) {
        case IDLE:
        case PENDING:
            // Set PS/2 output pins to output
            digitalWrite(_OutClockPin, HIGH);
            pinMode(_OutClockPin, OUTPUT);
            digitalWrite(_OutDataPin, HIGH);
            pinMode(_OutDataPin, OUTPUT);
            
            // Initiate clocking
            _keyb_clock = 1;
            _keyb_state = START;
            _keyb_parity = 1; // odd parity
            _keyb_bit = 0;
            
            // FALLTHROUGH
        case START:
            if (_keyb_clock == 1) {
                // Falling edge.  Set data
                digitalWrite(_OutDataPin, LOW); // start bit
                digitalWrite(_OutClockPin, LOW); // falling edge (host will read)
                _keyb_clock = 0;
            }
            else {
                digitalWrite(_OutClockPin, HIGH); // rising edge.  next send data
                _keyb_clock = 1;
                _keyb_bit = 0;
                _keyb_state = DATA;
            }
            break;
        case DATA:
            if (_keyb_clock == 1) {
                // Falling edge.  Set data
                if ((_keyb_data[_keyb_i] >> _keyb_bit) & 0x01 == 0x01) {
                    digitalWrite(_OutDataPin, HIGH);
                    _keyb_parity = 1 - _keyb_parity;
                }
                else {
                    digitalWrite(_OutDataPin, LOW);
                }
                digitalWrite(_OutClockPin, LOW); // falling edge (host will read)
                _keyb_clock = 0;
            }
            else {
                digitalWrite(_OutClockPin, HIGH); // rising edge.  next send data
                _keyb_clock = 1;
                _keyb_bit++;
                if (_keyb_bit == 8) {
                    _keyb_state = PARITY;
                }
            }
            break;
        case PARITY:
            if (_keyb_clock == 1) {
                // Falling edge.  Set data
                digitalWrite(_OutDataPin, _keyb_parity);
                digitalWrite(_OutClockPin, LOW); // falling edge (host will read)
                _keyb_clock = 0;
            }
            else {
                digitalWrite(_OutClockPin, HIGH); // rising edge.  next send data
                _keyb_clock = 1;
                _keyb_state = STOP;
            }
            break;
        case STOP: // stop bit
            if (_keyb_clock == 1) {
                // Falling edge.  Set data
                digitalWrite(_OutDataPin, HIGH); // stop bit
                digitalWrite(_OutClockPin, LOW); // falling edge (host will read)
                _keyb_clock = 0;
            }
            else {
                digitalWrite(_OutClockPin, HIGH); // rising edge.  next send data
                _keyb_clock = 1;
                _keyb_state = WAIT;
                waitclocks = WAITCLOCKS;
            }
            break;
        case WAIT:
            if (--waitclocks == 0) {
                _keyb_i++;
                if (_keyb_i < _keyb_len) {
                    _keyb_state = START;
                }
                else {
                    // Set PS/2 output pins to input
                    digitalWrite(_OutClockPin, HIGH);
                    pinMode(_OutClockPin, INPUT);
                    digitalWrite(_OutDataPin, HIGH);
                    pinMode(_OutDataPin, INPUT);

                    _keyb_state = IDLE;
                }
            }
            break;
        }
    }
}

